| Steps | Nodes | n pairs | Full bytes | Bounded bytes | Reduction % [95% CI] | Holm p |
|---|---|---|---|---|---|---|
| 10 | 50 | 5 | 135143 | 63775 | 52.81 [52.81; 52.82] | 0.06250 |
